#include <inttypes.h>
#include <avr/io.h>

void delay_ms(int t)
{
	int		i, j, k;
	
	for (i = 0; i < t+1; i++)
	{
		for (j = 0; j < 110; j++)
		{
			k++;
		}
	}
}

void init()
{
	DDRA = 0x00;
	DDRC = 0xFF;
}
