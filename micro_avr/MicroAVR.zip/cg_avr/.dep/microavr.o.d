microavr.o: microavr.c microavr.h C:/WinAVR/avr/include/inttypes.h \
  C:/WinAVR/avr/include/avr/io.h C:/WinAVR/avr/include/avr/sfr_defs.h \
  C:/WinAVR/avr/include/avr/iom8515.h

microavr.h:

C:/WinAVR/avr/include/inttypes.h:

C:/WinAVR/avr/include/avr/io.h:

C:/WinAVR/avr/include/avr/sfr_defs.h:

C:/WinAVR/avr/include/avr/iom8515.h:
